#define QT_FEATURE_xml_schema 1
