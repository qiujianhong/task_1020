#define QT_FEATURE_asm_hwcap_h -1
